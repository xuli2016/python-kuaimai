from dataclasses import asdict, is_dataclass
from typing import Any, Dict


class MissingDependencyError(RuntimeError):
    """Raised when an optional runtime dependency is missing."""


class JavaBeanMixin:
    """Provides Java-style getX/setX/isX accessors for migration-friendly APIs."""

    def __getattr__(self, name: str) -> Any:
        if len(name) > 3 and name.startswith("set"):
            attr_name = name[3:4].lower() + name[4:]

            def setter(value: Any) -> Any:
                setattr(self, attr_name, value)
                return self

            return setter
        if len(name) > 3 and name.startswith("get"):
            attr_name = name[3:4].lower() + name[4:]

            def getter() -> Any:
                return getattr(self, attr_name, None)

            return getter
        if len(name) > 2 and name.startswith("is"):
            attr_name = name[2:3].lower() + name[3:]

            def getter() -> Any:
                return getattr(self, attr_name, None)

            return getter
        raise AttributeError(f"{self.__class__.__name__!s} has no attribute {name!r}")

    def to_dict(self) -> Dict[str, Any]:
        if is_dataclass(self):
            return asdict(self)
        return dict(self.__dict__)


def coalesce(value: Any, default: Any) -> Any:
    return default if value is None else value
