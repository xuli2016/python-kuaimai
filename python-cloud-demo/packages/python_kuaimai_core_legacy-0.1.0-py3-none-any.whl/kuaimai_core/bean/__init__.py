from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from kuaimai_core.common import JavaBeanMixin


@dataclass
class ResponseEnvelope(JavaBeanMixin):
    status: Optional[bool] = None
    data: Any = None
    message: Optional[str] = None
    code: Optional[int] = None

    @classmethod
    def success(
        cls,
        data: Any = None,
        message: Optional[str] = None,
        code: Optional[int] = None,
    ) -> "ResponseEnvelope":
        return cls(status=True, data=data, message=message, code=code)

    @classmethod
    def failure(
        cls,
        message: str,
        code: Optional[int] = None,
        data: Any = None,
    ) -> "ResponseEnvelope":
        return cls(status=False, data=data, message=message, code=code)

    @classmethod
    def from_payload(cls, payload: Any) -> "ResponseEnvelope":
        if isinstance(payload, cls):
            return payload
        if isinstance(payload, dict):
            return cls(
                status=payload.get("status"),
                data=payload.get("data"),
                message=payload.get("message"),
                code=payload.get("code"),
            )
        return cls.success(data=payload)


@dataclass
class CalculateRowsBO(JavaBeanMixin):
    map: Dict[int, str] = field(default_factory=dict)
    maxNumRows: int = 0


@dataclass
class TsplImageBO(JavaBeanMixin):
    bytes: Optional[bytes] = None
    bufferedImage: Any = None
