from __future__ import annotations

import json
import math
import os
from pathlib import Path
from typing import Any

from kuaimai_core.bean import ResponseEnvelope
from kuaimai_core.common import JavaBeanMixin
from kuaimai_core.constants import BASE_URL, DEFAULT_TIMEOUT, VERSION
from kuaimai_core.rendering import render_tspl_template
from kuaimai_core.request import (
    AdjustDeviceDensityRequest,
    BindDeviceRequest,
    BroadcastRequest,
    CainiaoBindRequest,
    CainiaoPrintRequest,
    CancelJobRequest,
    CombinationRequest,
    EscImageRequest,
    EscInstructRequest,
    EscPdfPrintRequest,
    EscTemplatePrintRequest,
    EscXmlWriteRequest,
    GetCainiaoCodeRequest,
    QueryDeviceExistRequest,
    QueryDeviceStatusRequest,
    ResultRequest,
    TsplImageRequest,
    TsplInstructRequest,
    TsplPdfPrintRequest,
    TsplTemplatePrintRequest,
    TsplTemplateWriteRequest,
    TsplXmlWriteRequest,
    UnbindDeviceRequest,
)
from kuaimai_core.utils import (
    base64_to_image,
    calculate_image_size_in_kb,
    compact_dict,
    convert_pdf_to_image,
    convert_pdf_to_images,
    create_sign,
    current_timestamp,
    encode_base64,
    get_esc_image_bytes,
    get_tspl_image_bytes,
    gzip_binary_bmp_base64,
    image_to_base64,
    is_blank,
    json_dumps,
    merge_bytes,
    mm_to_pixels,
    parse_json_if_needed,
    remove_base64_header,
    require_module,
    resize_image,
    to_binary_image,
)


class KuaimaiClient(JavaBeanMixin):
    def __init__(
        self,
        accessKey: str,
        secret: str,
        base_url: str = BASE_URL,
        session: Any | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self.accessKey = accessKey
        self.secret = secret
        self.base_url = base_url
        self.session = session
        self.timeout = timeout

    @classmethod
    def createClient(cls, accessKey: str, secret: str, **kwargs: Any) -> "KuaimaiClient":
        return cls(accessKey=accessKey, secret=secret, **kwargs)

    @classmethod
    def create_client(cls, access_key: str, secret: str, **kwargs: Any) -> "KuaimaiClient":
        return cls(accessKey=access_key, secret=secret, **kwargs)

    @staticmethod
    def _normalize_esc_print_width_mm(print_width: int | None) -> float | None:
        if print_width is None or print_width <= 0:
            return None
        # Common thermal printers expose 58/80mm paper widths, but their effective
        # printable widths are typically about 48/72mm.
        return {
            58: 48.0,
            80: 72.0,
        }.get(print_width, float(print_width))

    @classmethod
    def _fit_esc_image(cls, image: Any, print_width: int | None) -> Any:
        effective_width_mm = cls._normalize_esc_print_width_mm(print_width)
        if effective_width_mm is None:
            return image
        target_width = mm_to_pixels(effective_width_mm, 203)
        target_width = max(8, (target_width // 8) * 8)
        if image.width <= target_width:
            return image
        target_height = max(1, int(round(image.height * target_width / image.width)))
        return resize_image(image, target_width, target_height)

    def _build_payload(self, params: dict[str, Any], include_version: bool = False) -> dict[str, Any]:
        payload = {"appId": self.accessKey, "timestamp": current_timestamp()}
        payload.update(params)
        payload["sign"] = create_sign(payload, self.secret)
        if include_version:
            payload["version"] = VERSION
        return payload

    def _post(self, path: str, params: dict[str, Any], include_version: bool = False) -> ResponseEnvelope:
        payload = self._build_payload(params, include_version=include_version)
        url = self.base_url + path
        data = json_dumps(payload)
        try:
            if self.session is None:
                requests = require_module("requests", "requests")
                response = requests.post(
                    url,
                    data=data.encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    timeout=self.timeout,
                )
            else:
                response = self.session.post(
                    url,
                    data=data,
                    headers={"Content-Type": "application/json"},
                    timeout=self.timeout,
                )
            text = getattr(response, "text", None)
            if text is None and hasattr(response, "json"):
                payload = response.json()
            else:
                payload = json.loads(text or "{}")
            return ResponseEnvelope.from_payload(payload)
        except Exception as exc:  # pragma: no cover - exercised with mock sessions in tests
            if "UnknownHost" in str(exc) or "Name or service not known" in str(exc):
                return ResponseEnvelope.failure("本地网络不通")
            return ResponseEnvelope.failure(f"请求失败:{exc}")

    def queryDeviceExist(self, request: QueryDeviceExistRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        return self._post("device/exist", {"sn": request.sn}, include_version=True)

    def queryDeviceStatus(self, request: QueryDeviceStatusRequest) -> ResponseEnvelope:
        if is_blank(request.sn) and is_blank(request.sns):
            return ResponseEnvelope.failure("sn入参为空")
        sns = request.sns
        if is_blank(sns):
            sns = json.dumps([request.sn], ensure_ascii=False)
        return self._post("device/batchStatus", {"snsStr": sns}, include_version=True)

    def escInstruct(self, request: EscInstructRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        if is_blank(request.instructions):
            return ResponseEnvelope.failure("instructions入参为空")
        return self._post(
            "print/escWrite",
            compact_dict(
                [
                    ("sn", request.sn),
                    ("instructionsList", request.instructions),
                    ("copies", request.copies),
                    ("volume", request.volume),
                    ("volumeContent", request.volumeContent),
                    ("volumeIndex", request.volumeIndex),
                ]
            ),
            include_version=True,
        )

    def tsplInstruct(self, request: TsplInstructRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        if is_blank(request.instructs):
            return ResponseEnvelope.failure("指令内容为空")
        return self._post(
            "print/deviceWrite",
            compact_dict(
                [
                    ("sn", request.sn),
                    ("instructs", request.instructs),
                    ("prereq", request.prereq),
                    ("extra", request.extra),
                ]
            ),
            include_version=True,
        )

    def result(self, request: ResultRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        job_ids = parse_json_if_needed(request.jobIds)
        if not job_ids:
            return ResponseEnvelope.failure("jobId为空")
        return self._post(
            "print/result",
            compact_dict(
                [
                    ("sn", request.sn),
                    ("jobIds", job_ids),
                    ("jobIdStr", request.jobIdStr),
                ]
            ),
            include_version=True,
        )

    def combination(self, request: CombinationRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        tspl_request = TsplInstructRequest(
            sn=request.sn,
            instructs=request.instructs,
            prereq=request.prereq or "FFFF01",
            extra=request.extra or "2",
        )
        return self.tsplInstruct(tspl_request)

    def escTemplatePrint(self, request: EscTemplatePrintRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        return self._post(
            "print/escTemplatePrint",
            compact_dict(
                [
                    ("sn", request.sn),
                    ("templateId", request.templateId),
                    ("renderDataJson", parse_json_if_needed(request.renderDataJson)),
                    ("renderData", request.renderData),
                    ("cut", request.cut),
                    ("volume", request.volume),
                    ("volumeIndex", request.volumeIndex),
                    ("volumeContent", request.volumeContent),
                    ("copies", request.copies),
                    ("type", request.type),
                    ("endFeed", request.endFeed),
                ]
            ),
        )

    def tsplTemplatePrint(self, request: TsplTemplatePrintRequest) -> ResponseEnvelope:
        if not is_blank(request.imei) and is_blank(request.sn):
            return self.tsplImageCainiaoPrint(request)
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        if request.templateId is None:
            return ResponseEnvelope.failure("templateId不能为空")
        if request.image:
            return self.tsplImagePrint(request)
        return self._post(
            "print/tsplTemplatePrint",
            compact_dict(
                [
                    ("sn", request.sn),
                    ("templateId", request.templateId),
                    ("renderDataJson", parse_json_if_needed(request.renderDataJson)),
                    ("renderDataJsonArray", parse_json_if_needed(request.renderDataJsonArray)),
                    ("renderDataArray", request.renderDataArray),
                    ("printTimes", request.printTimes),
                ]
            ),
        )

    def tsplTemplateWrite(self, request: TsplTemplateWriteRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        return self._post(
            "print/tsplTemplateWrite",
            compact_dict(
                [
                    ("sn", request.sn),
                    ("templateId", request.templateId),
                    ("renderDataJson", parse_json_if_needed(request.renderDataJson)),
                    ("renderDataJsonArray", parse_json_if_needed(request.renderDataJsonArray)),
                    ("renderData", request.renderData),
                    ("printTimes", request.printTimes),
                ]
            ),
        )

    def bindDevice(self, request: BindDeviceRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        return self._post(
            "device/bindDevice",
            compact_dict(
                [
                    ("sn", request.sn),
                    ("deviceKey", request.deviceKey),
                    ("bindName", request.bindName),
                    ("noteName", request.noteName),
                ]
            ),
        )

    def tsplXmlWrite(self, request: TsplXmlWriteRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        return self._post(
            "print/tsplXmlWrite",
            compact_dict(
                [
                    ("sn", request.sn),
                    ("xmlStr", request.xmlStr),
                    ("printTimes", request.printTimes),
                    ("image", request.image),
                    ("jobs", parse_json_if_needed(request.jobs)),
                ]
            ),
        )

    def escXmlWrite(self, request: EscXmlWriteRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        return self._post(
            "print/escXmlWrite",
            compact_dict(
                [
                    ("sn", request.sn),
                    ("instructions", request.instructions),
                    ("volume", request.volume),
                    ("volumeIndex", request.volumeIndex),
                    ("cut", request.cut),
                ]
            ),
        )

    def tsplPdfPrint(self, request: TsplPdfPrintRequest) -> ResponseEnvelope:
        pdf_path = Path(os.fspath(request.file)) if request.file is not None else None
        if pdf_path is None or not pdf_path.exists():
            return ResponseEnvelope.failure("pdf文件不存在")
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参不能为空")
        dpi = 203 if request.dpi is None else request.dpi
        image = convert_pdf_to_image(pdf_path, dpi=dpi)
        tspl_request = TsplImageRequest(
            sn=request.sn,
            bufferedImage=image,
            dpi=dpi,
            setWidth=75 if request.width is None else request.width,
            setHeight=100 if request.height is None else request.height,
        )
        return self.tsplImageDirectPrint(tspl_request)

    def tsplPdfsPrint(self, request: TsplPdfPrintRequest) -> ResponseEnvelope:
        pdf_path = Path(os.fspath(request.file)) if request.file is not None else None
        if pdf_path is None or not pdf_path.exists():
            return ResponseEnvelope.failure("pdf文件不存在")
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参不能为空")
        dpi = 203 if request.dpi is None else request.dpi
        width = 75 if request.width is None else request.width
        height = 100 if request.height is None else request.height
        responses = []
        for image in convert_pdf_to_images(pdf_path, dpi=dpi):
            responses.append(
                self.tsplImageDirectPrint(
                    TsplImageRequest(
                        sn=request.sn,
                        bufferedImage=image,
                        dpi=dpi,
                        setWidth=width,
                        setHeight=height,
                    )
                )
            )
        return ResponseEnvelope.success(responses)

    def tsplImageDirectPrint(self, request: TsplImageRequest) -> ResponseEnvelope:
        if is_blank(request.imageBase64) and request.bufferedImage is None:
            return ResponseEnvelope.failure("入参不能为空")
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        image = request.bufferedImage or base64_to_image(remove_base64_header(request.imageBase64) or "")
        dpi = request.dpi
        if request.setWidth is not None and request.setHeight is not None:
            if dpi == 300:
                pixel_width = int(math.floor((request.setWidth * 11.8) / 8) * 8)
                pixel_height = int(math.floor((request.setHeight * 11.8) / 8) * 8)
            else:
                pixel_width = request.setWidth * 8
                pixel_height = request.setHeight * 8
            image = resize_image(image, pixel_width, pixel_height)
            page_width = request.setWidth
            page_height = request.setHeight
        else:
            if dpi == 300:
                page_width = int(math.ceil(image.width / 11.8))
                page_height = int(math.ceil(image.height / 11.8))
            else:
                page_width = int(math.ceil(image.width / 8))
                page_height = int(math.ceil(image.height / 8))
        if calculate_image_size_in_kb(image) > 300:
            return ResponseEnvelope.failure("图片大小不能超过300KB")
        print_times = 1 if request.printTimes is None else request.printTimes
        instruct = merge_bytes(
            f"SIZE {page_width} mm,{page_height} mm\r\n".encode("gbk"),
            b"CLS\r\n",
            get_tspl_image_bytes(image, compress=True),
            f"PRINT 1,{print_times}\r\n".encode("gbk"),
        )
        return self.tsplImageWrite(
            TsplInstructRequest(
                sn=request.sn,
                instructs=encode_base64(instruct),
                prereq="FFFF01",
                extra="0",
            )
        )

    def escPdfPrint(self, request: EscPdfPrintRequest) -> ResponseEnvelope:
        pdf_path = Path(os.fspath(request.file)) if request.file is not None else None
        if pdf_path is None or not pdf_path.exists():
            return ResponseEnvelope.failure("pdf文件不存在")
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参不能为空")
        image = convert_pdf_to_image(pdf_path, dpi=203)
        esc_request = EscImageRequest(
            sn=request.sn,
            bufferedImage=image,
            printWidth=58 if request.printWidth is None else request.printWidth,
            endFeed=request.endFeed,
        )
        return self.escImageDirectPrint(esc_request)

    def escPdfsPrint(self, request: EscPdfPrintRequest) -> ResponseEnvelope:
        pdf_path = Path(os.fspath(request.file)) if request.file is not None else None
        if pdf_path is None or not pdf_path.exists():
            return ResponseEnvelope.failure("pdf文件不存在")
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参不能为空")
        print_width = 58 if request.printWidth is None else request.printWidth
        responses = []
        for image in convert_pdf_to_images(pdf_path, dpi=203):
            responses.append(
                self.escImageDirectPrint(
                    EscImageRequest(
                        sn=request.sn,
                        bufferedImage=image,
                        printWidth=print_width,
                        endFeed=request.endFeed,
                    )
                )
            )
        return ResponseEnvelope.success(responses)

    def escImageDirectPrint(self, request: EscImageRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参不能为空")
        if is_blank(request.imageBase64) and request.bufferedImage is None:
            return ResponseEnvelope.failure("imageBase64和bufferedImage入参不能都为空")
        image = request.bufferedImage or base64_to_image(remove_base64_header(request.imageBase64) or "")
        image = self._fit_esc_image(image, request.printWidth)
        binary = to_binary_image(image)
        if calculate_image_size_in_kb(binary) > 300:
            return ResponseEnvelope.failure("图片大小不能超过300KB")
        end_feed = 3 if request.endFeed is None else request.endFeed
        instruct = merge_bytes(
            bytes([0x1B, 0x40]),
            bytes([31, 27, 26, 1, 2, 4, request.printWidth]) if request.printWidth else b"",
            get_esc_image_bytes(binary, compress=True),
            bytes([0x1B, 0x64, end_feed]),
        )
        return self.tsplImageWrite(
            TsplInstructRequest(
                sn=request.sn,
                instructs=encode_base64(instruct),
                prereq="FFFF01",
                extra="2",
            )
        )

    def adjustDeviceDensity(self, request: AdjustDeviceDensityRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参不能为空")
        if request.density is None:
            return ResponseEnvelope.failure("density入参不能为空")
        if request.density < 1 or request.density > 15:
            return ResponseEnvelope.failure("density入参范围需要为1～15")
        return self._post(
            "device/adjustDeviceDensity",
            {"sn": request.sn, "density": request.density},
            include_version=True,
        )

    def getTemplate(self, templateId: int | None) -> ResponseEnvelope | None:
        if templateId is None:
            return None
        return self._post("print/getTemplate", {"templateId": templateId})

    def _template_render_items(self, request: TsplTemplatePrintRequest, template_response: ResponseEnvelope) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        template_data = dict(template_response.data or {})
        template_data["tagConfig"] = parse_json_if_needed(template_data.get("tagConfig") or {}) or {}
        template_data["templateData"] = parse_json_if_needed(template_data.get("templateData") or {}) or {}
        render_data_array = parse_json_if_needed(request.renderDataJsonArray)
        if render_data_array is None:
            render_data_array = parse_json_if_needed(request.renderDataArray)
        render_data_array = render_data_array or []
        return template_data, render_data_array

    def tsplImageCainiaoPrint(self, request: TsplTemplatePrintRequest) -> ResponseEnvelope:
        template = self.getTemplate(request.templateId)
        if template is None:
            return ResponseEnvelope.failure("模板不存在")
        if not template.status:
            return template
        template_data, render_data_array = self._template_render_items(request, template)
        for render_data in render_data_array:
            tspl_image = render_tspl_template(template_data, render_data, request.printTimes)
            response = self.cainiaoPrint(
                CainiaoPrintRequest(
                    imei=request.imei,
                    imageBase64Data=image_to_base64(tspl_image.bufferedImage, "PNG"),
                )
            )
            if not response.status:
                return response
        return ResponseEnvelope.success(message="下发成功")

    def tsplImagePrint(self, request: TsplTemplatePrintRequest) -> ResponseEnvelope:
        template = self.getTemplate(request.templateId)
        if template is None:
            return ResponseEnvelope.failure("模板不存在")
        if not template.status:
            return template
        template_data, render_data_array = self._template_render_items(request, template)
        dpi = request.dpi
        tag_config = template_data.get("tagConfig") or {}
        if dpi == 300:
            responses = []
            for render_data in render_data_array:
                tspl_image = render_tspl_template(template_data, render_data, request.printTimes)
                responses.append(
                    self.tsplImageDirectPrint(
                        TsplImageRequest(
                            sn=request.sn,
                            bufferedImage=tspl_image.bufferedImage,
                            dpi=300,
                            setWidth=int(round(float(tag_config.get("width") or 75))),
                            setHeight=int(round(float(tag_config.get("height") or 100))),
                        )
                    )
                )
            return ResponseEnvelope.success(responses)
        instruct = bytearray()
        for render_data in render_data_array:
            tspl_image = render_tspl_template(template_data, render_data, request.printTimes)
            instruct.extend(tspl_image.bytes or b"")
        encoded = encode_base64(bytes(instruct))
        if len(encoded.encode("utf-8")) > 150 * 1024:
            return ResponseEnvelope.failure("渲染数据量过大,请减少渲染数量")
        return self.tsplImageWrite(
            TsplInstructRequest(
                sn=request.sn,
                extra="0",
                prereq="FFFF01",
                instructs=encoded,
            )
        )

    def tsplImageWrite(self, request: TsplInstructRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参为空")
        if is_blank(request.instructs):
            return ResponseEnvelope.failure("指令内容为空")
        return self._post(
            "print/imageWrite",
            compact_dict(
                [
                    ("sn", request.sn),
                    ("instructs", request.instructs),
                    ("prereq", request.prereq),
                    ("extra", request.extra),
                ]
            ),
            include_version=True,
        )

    def unbindDevice(self, request: UnbindDeviceRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参不能为空")
        if is_blank(request.deviceKey):
            return ResponseEnvelope.failure("deviceKey入参不能为空")
        return self._post(
            "device/unbindDevice",
            {"sn": request.sn, "deviceKey": request.deviceKey},
            include_version=True,
        )

    def cancelJob(self, request: CancelJobRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参不能为空")
        return self._post("print/cancelJob", {"sn": request.sn}, include_version=True)

    def broadcast(self, request: BroadcastRequest) -> ResponseEnvelope:
        if is_blank(request.sn):
            return ResponseEnvelope.failure("sn入参不能为空")
        if request.volume is None:
            return ResponseEnvelope.failure("volume入参不能为空")
        if is_blank(request.volumeContent):
            return ResponseEnvelope.failure("volumeContent入参不能为空")
        return self._post(
            "device/broadcast",
            {"sn": request.sn, "volume": request.volume, "volumeContent": request.volumeContent},
            include_version=True,
        )

    def getCainiaoCode(self, request: GetCainiaoCodeRequest) -> ResponseEnvelope:
        if is_blank(request.imei):
            return ResponseEnvelope.failure("imei入参为空")
        return self._post("print/getCainiaoCode", {"imei": request.imei}, include_version=True)

    def cainiaoBind(self, request: CainiaoBindRequest) -> ResponseEnvelope:
        if is_blank(request.code) or is_blank(request.imei):
            return ResponseEnvelope.failure("code或imei入参为空")
        return self._post(
            "print/cainiaoBind",
            {"imei": request.imei, "code": request.code},
            include_version=True,
        )

    def cainiaoPrint(self, request: CainiaoPrintRequest) -> ResponseEnvelope:
        if is_blank(request.imei) or is_blank(request.imageBase64Data):
            return ResponseEnvelope.failure("imei或imageBase64Data入参为空")
        try:
            print_data = gzip_binary_bmp_base64(remove_base64_header(request.imageBase64Data) or "")
        except Exception as exc:
            return ResponseEnvelope.failure(f"图片处理异常:{exc}")
        return self._post(
            "print/cainiaoPrint",
            {"imei": request.imei, "printData": print_data},
            include_version=True,
        )

    @staticmethod
    def processBase64ImageToGzippedBinaryBmp(base64Image: str) -> str:
        return gzip_binary_bmp_base64(base64Image)

    @staticmethod
    def process_base64_image_to_gzipped_binary_bmp(base64_image: str) -> str:
        return gzip_binary_bmp_base64(base64_image)

    def getAcsResponse(self, request: Any) -> ResponseEnvelope | None:
        if request is None:
            return None
        dispatch_map = {
            QueryDeviceExistRequest: self.queryDeviceExist,
            QueryDeviceStatusRequest: self.queryDeviceStatus,
            EscInstructRequest: self.escInstruct,
            TsplInstructRequest: self.tsplInstruct,
            ResultRequest: self.result,
            CombinationRequest: self.combination,
            EscTemplatePrintRequest: self.escTemplatePrint,
            TsplTemplatePrintRequest: self.tsplTemplatePrint,
            TsplTemplateWriteRequest: self.tsplTemplateWrite,
            BindDeviceRequest: self.bindDevice,
            TsplXmlWriteRequest: self.tsplXmlWrite,
            EscXmlWriteRequest: self.escXmlWrite,
            TsplImageRequest: self.tsplImageDirectPrint,
            EscImageRequest: self.escImageDirectPrint,
            GetCainiaoCodeRequest: self.getCainiaoCode,
            CainiaoBindRequest: self.cainiaoBind,
            CainiaoPrintRequest: self.cainiaoPrint,
            BroadcastRequest: self.broadcast,
            CancelJobRequest: self.cancelJob,
            UnbindDeviceRequest: self.unbindDevice,
            AdjustDeviceDensityRequest: self.adjustDeviceDensity,
            TsplPdfPrintRequest: self.tsplPdfPrint,
            EscPdfPrintRequest: self.escPdfPrint,
        }
        for request_type, handler in dispatch_map.items():
            if isinstance(request, request_type):
                return handler(request)
        return None

    def get_acs_response(self, request: Any) -> ResponseEnvelope | None:
        return self.getAcsResponse(request)


def create_client(access_key: str, secret: str, **kwargs: Any) -> KuaimaiClient:
    return KuaimaiClient.create_client(access_key, secret, **kwargs)


def createClient(accessKey: str, secret: str, **kwargs: Any) -> KuaimaiClient:
    return KuaimaiClient.createClient(accessKey, secret, **kwargs)
