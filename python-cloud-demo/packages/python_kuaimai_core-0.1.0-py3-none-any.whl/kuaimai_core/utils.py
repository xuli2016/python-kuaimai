from __future__ import annotations

import base64
import gzip
import hashlib
import importlib
import importlib.util
import io
import json
import math
import os
import shutil
import subprocess
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable

from kuaimai_core.common import MissingDependencyError
from kuaimai_core.constants import COMMON_FONT_FAMILIES, COMMON_FONT_PATHS, FONT_ALIAS_FAMILIES, FONT_HINT_PATHS


def module_available(name: str) -> bool:
    return importlib.util.find_spec(name) is not None


def require_module(module_name: str, package_name: str | None = None) -> Any:
    package_name = package_name or module_name
    try:
        return importlib.import_module(module_name)
    except ModuleNotFoundError as exc:
        raise MissingDependencyError(
            f"{package_name} is required for this feature. Install project dependencies first."
        ) from exc


def current_timestamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def is_blank(value: Any) -> bool:
    return value is None or (isinstance(value, str) and value.strip() == "")


def json_dumps(data: Any) -> str:
    return json.dumps(data, ensure_ascii=False, separators=(",", ":"))


def stringify_for_sign(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (dict, list, tuple)):
        return json_dumps(value)
    return str(value)


def create_sign(params: dict[str, Any], verify_secret: str) -> str:
    query = [verify_secret]
    for key in sorted(params.keys()):
        value = params[key]
        if key is None or value is None:
            continue
        key_string = str(key)
        value_string = stringify_for_sign(value)
        if not is_blank(key_string) and not is_blank(value_string):
            query.append(key_string)
            query.append(value_string)
    query.append(verify_secret)
    return hashlib.md5("".join(query).encode("utf-8")).hexdigest()


def remove_base64_header(base64_str: str | None) -> str | None:
    if base64_str is None:
        return None
    marker = ";base64,"
    index = base64_str.find(marker)
    return base64_str[index + len(marker) :] if index > -1 else base64_str


def merge_bytes(*parts: bytes) -> bytes:
    return b"".join(part for part in parts if part)


def encode_base64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def decode_base64(data: str) -> bytes:
    return base64.b64decode(data)


def image_modules() -> tuple[Any, Any, Any, Any, Any]:
    image_mod = require_module("PIL.Image", "Pillow")
    draw_mod = require_module("PIL.ImageDraw", "Pillow")
    font_mod = require_module("PIL.ImageFont", "Pillow")
    ops_mod = require_module("PIL.ImageOps", "Pillow")
    color_mod = require_module("PIL.ImageColor", "Pillow")
    return image_mod, draw_mod, font_mod, ops_mod, color_mod


def _normalize_font_key(value: str | None) -> str:
    return (value or "").lower().replace(" ", "").replace("-", "").replace("_", "")


def _fc_match_font_path(font_family: str | None) -> str | None:
    if is_blank(font_family) or shutil.which("fc-match") is None:
        return None
    try:
        result = subprocess.run(
            ["fc-match", "-f", "%{file}\n", str(font_family)],
            capture_output=True,
            text=True,
            check=False,
        )
    except OSError:
        return None
    path = (result.stdout or "").splitlines()
    if not path:
        return None
    resolved = os.path.expanduser(path[0].strip())
    return resolved if resolved and Path(resolved).exists() else None


def get_default_font_candidates(font_family: str | None = None) -> list[str]:
    candidates: list[str] = []
    seen: set[str] = set()

    def add_candidate(candidate: str | None) -> None:
        if is_blank(candidate):
            return
        expanded = os.path.expanduser(str(candidate))
        if expanded in seen:
            return
        seen.add(expanded)
        candidates.append(expanded)

    if font_family:
        normalized = _normalize_font_key(font_family)
        for path in FONT_HINT_PATHS.get(normalized, ()):
            add_candidate(path)
        fc_path = _fc_match_font_path(font_family)
        add_candidate(fc_path)
        for path in COMMON_FONT_PATHS:
            expanded_path = os.path.expanduser(path)
            if normalized and normalized in _normalize_font_key(Path(expanded_path).stem):
                add_candidate(expanded_path)
        for alias in FONT_ALIAS_FAMILIES.get(normalized, ()):
            add_candidate(alias)
        add_candidate(font_family)
    for path in COMMON_FONT_PATHS:
        add_candidate(path)
    for family in COMMON_FONT_FAMILIES:
        add_candidate(family)
    return candidates


def load_font(size: int, font_family: str | None = None) -> Any:
    _, _, font_mod, _, _ = image_modules()
    for candidate in get_default_font_candidates(font_family):
        try:
            return font_mod.truetype(os.path.expanduser(candidate), size=size)
        except OSError:
            continue
    return font_mod.load_default()


def base64_to_image(base64_image: str) -> Any:
    image_mod, _, _, _, _ = image_modules()
    raw = decode_base64(remove_base64_header(base64_image) or "")
    return image_mod.open(io.BytesIO(raw)).convert("RGBA")


def image_to_base64(image: Any, format_name: str = "PNG") -> str:
    buffer = io.BytesIO()
    image.save(buffer, format_name)
    return encode_base64(buffer.getvalue())


def resize_image(image: Any, width: int, height: int) -> Any:
    image_mod, _, _, _, _ = image_modules()
    return image.resize((max(1, width), max(1, height)), image_mod.Resampling.LANCZOS)


def rotate_image(image: Any, angle: float) -> Any:
    return image.rotate(-angle, expand=True, fillcolor="white")


def to_binary_image(image: Any) -> Any:
    grayscale = image.convert("L")
    return grayscale.point(lambda value: 255 if value >= 200 else 0, mode="1")


def calculate_image_size_in_kb(image: Any) -> float:
    return (image.width * image.height) / (8 * 1024)


def mm_to_pixels(mm_value: float, dpi: int) -> int:
    return max(1, int(round(mm_value * dpi / 25.4)))


def chunk_image_by_height(image: Any, max_chunk_kb: int = 50) -> list[tuple[int, Any]]:
    total_size = calculate_image_size_in_kb(image)
    chunk_count = max(1, int(math.ceil(total_size / max_chunk_kb)))
    if chunk_count == 1:
        return [(0, image)]
    chunk_height = max(1, image.height // chunk_count)
    chunks: list[tuple[int, Any]] = []
    for index in range(chunk_count):
        top = chunk_height * index
        bottom = image.height if index == chunk_count - 1 else min(image.height, top + chunk_height)
        chunks.append((top, image.crop((0, top, image.width, bottom))))
    return chunks


def _pack_raster_bits(image: Any, zero_for_white: bool) -> tuple[int, int, bytes]:
    mono = image.convert("1")
    width, height = mono.size
    row_bytes = (width + 7) // 8
    packed = bytearray()
    pad_bit = 0 if zero_for_white else 1
    for y in range(height):
        row = 0
        bit_count = 0
        for x in range(width):
            pixel = mono.getpixel((x, y))
            is_white = pixel in (255, 1, True)
            bit = 0 if is_white else 1
            if not zero_for_white:
                bit = 1 - bit
            row = (row << 1) | bit
            bit_count += 1
            if bit_count == 8:
                packed.append(row)
                row = 0
                bit_count = 0
        if bit_count:
            for _ in range(8 - bit_count):
                row = (row << 1) | pad_bit
            packed.append(row)
    return row_bytes, height, bytes(packed)


def get_tspl_image_bytes(image: Any, compress: bool = True) -> bytes:
    parts: list[bytes] = []
    for offset, chunk in chunk_image_by_height(image):
        row_bytes, height, bitmap = _pack_raster_bits(chunk, zero_for_white=False)
        header = f"BITMAP 0,{offset},{row_bytes},{height},0,".encode("gbk")
        parts.append(merge_bytes(header, bitmap, b"\r\n"))
    return merge_bytes(*parts)


def get_esc_image_bytes(image: Any, compress: bool = True) -> bytes:
    parts: list[bytes] = []
    for _, chunk in chunk_image_by_height(image):
        row_bytes, height, bitmap = _pack_raster_bits(chunk, zero_for_white=True)
        height_low = height % 256
        height_high = height // 256
        header = bytes([0x1D, 0x76, 0x30, 0x00, row_bytes, 0x00, height_low, height_high])
        parts.append(merge_bytes(header, bitmap))
    return merge_bytes(*parts)


def gzip_binary_bmp_base64(base64_image: str) -> str:
    image_mod, _, _, _, _ = image_modules()
    image = base64_to_image(base64_image)
    binary = to_binary_image(image)
    buffer = io.BytesIO()
    binary.convert("1").save(buffer, format="BMP")
    return encode_base64(gzip.compress(buffer.getvalue()))


def draw_qrcode(content: str, width: int, height: int) -> Any:
    qrcode_mod = require_module("qrcode", "qrcode")
    image_mod, _, _, _, _ = image_modules()
    qr = qrcode_mod.QRCode(border=0, box_size=10)
    qr.add_data(content)
    qr.make(fit=True)
    image = qr.make_image(fill_color="black", back_color="white").convert("RGBA")
    return image.resize((max(1, width), max(1, height)), image_mod.Resampling.NEAREST)


def _identity_transform() -> tuple[float, float, float, float, float, float]:
    return (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)


def _normalize_transform(transform: Any) -> tuple[float, float, float, float, float, float]:
    if isinstance(transform, (list, tuple)) and len(transform) == 6:
        return tuple(float(value) for value in transform)
    return _identity_transform()


def _compose_transform(
    parent: tuple[float, float, float, float, float, float],
    child: tuple[float, float, float, float, float, float],
) -> tuple[float, float, float, float, float, float]:
    a1, b1, c1, d1, e1, f1 = parent
    a2, b2, c2, d2, e2, f2 = child
    return (
        a1 * a2 + c1 * b2,
        b1 * a2 + d1 * b2,
        a1 * c2 + c1 * d2,
        b1 * c2 + d1 * d2,
        a1 * e2 + c1 * f2 + e1,
        b1 * e2 + d1 * f2 + f1,
    )


def _transform_point(
    transform: tuple[float, float, float, float, float, float],
    x: float,
    y: float,
) -> tuple[float, float]:
    a, b, c, d, e, f = transform
    return (a * x + c * y + e, b * x + d * y + f)


def _reportlab_color_to_rgba(color: Any) -> tuple[int, int, int, int] | None:
    if color is None:
        return None
    red = int(round(float(getattr(color, "red", 0.0)) * 255))
    green = int(round(float(getattr(color, "green", 0.0)) * 255))
    blue = int(round(float(getattr(color, "blue", 0.0)) * 255))
    alpha = int(round(float(getattr(color, "alpha", 1.0)) * 255))
    return (red, green, blue, alpha)


def _barcode_placeholder(content: str, width: int, height: int) -> Any:
    image_mod, draw_mod, _, _, _ = image_modules()
    image = image_mod.new("RGBA", (max(1, width), max(1, height)), "white")
    draw = draw_mod.Draw(image)
    draw.rectangle((0, 0, width - 1, height - 1), outline="black")
    draw.text((4, max(1, height // 2 - 6)), content, fill="black")
    return image


def _fit_barcode_text_font(draw: Any, content: str, width: int, height: int, font_name: str | None, font_size: int) -> Any:
    target_size = max(6, min(max(6, font_size), max(6, height)))
    for size in range(target_size, 5, -1):
        font = load_font(size, font_name)
        left, top, right, bottom = draw.textbbox((0, 0), content, font=font)
        if (right - left) <= width and (bottom - top) <= height:
            return font
    return load_font(6, font_name)


@lru_cache(maxsize=128)
def _generate_treepoem_base_barcode(treepoem_type: str, content: str) -> Any | None:
    treepoem = require_module("treepoem", "treepoem")
    try:
        return treepoem.generate_barcode(
            barcode_type=treepoem_type,
            data=content,
            scale=1,
        ).convert("RGBA")
    except Exception:
        return None


def _draw_treepoem_barcode(
    content: str,
    width: int,
    height: int,
    barcode_type: str,
    human_readable: str,
    font_name: str | None,
    font_size: int,
) -> Any | None:
    if not module_available("treepoem") or shutil.which("gs") is None:
        return None

    treepoem = require_module("treepoem", "treepoem")
    type_map = {
        "CODE128": "code128",
        "CODE39": "code39",
        "CODE93": "code93",
        "EAN8": "ean8",
        "EAN13": "ean13",
        "ITF": "interleaved2of5",
        "UPC": "upca",
        "CODABAR": "rationalizedCodabar",
    }
    treepoem_type = type_map.get(barcode_type)
    if not treepoem_type:
        return None

    image_mod, draw_mod, _, _, _ = image_modules()
    preview = image_mod.new("RGBA", (max(1, width), max(1, height)), "white")
    preview_draw = draw_mod.Draw(preview)

    position = (human_readable or "none")
    if position is True or position == "all":
        position = "bottom"
    position = str(position).lower()
    if position not in {"top", "bottom"}:
        position = "none"

    text_box_height = 0
    text_font = None
    if position != "none":
        max_text_height = max(8, min(int(height * 0.4), max(8, height - 10)))
        text_font = _fit_barcode_text_font(
            preview_draw,
            content,
            max(1, width - 2),
            max_text_height,
            font_name,
            font_size,
        )
        left, top, right, bottom = preview_draw.textbbox((0, 0), content, font=text_font)
        text_height = bottom - top
        text_box_height = min(max(text_height + 4, 10), max(10, height - 10))

    barcode_area_height = max(1, height - text_box_height) if position != "none" else max(1, height)
    base_barcode = _generate_treepoem_base_barcode(treepoem_type, content)
    if base_barcode is None:
        return None
    best_image = base_barcode.copy()
    if best_image.width > width:
        return None
    target_bar_height = max(1, barcode_area_height)
    if best_image.height != target_bar_height:
        best_image = best_image.resize((best_image.width, target_bar_height), image_mod.Resampling.NEAREST)

    result = image_mod.new("RGBA", (max(1, width), max(1, height)), "white")
    barcode_left = max(0, (width - best_image.width) // 2)
    if position == "top":
        barcode_top = text_box_height + max(0, (barcode_area_height - best_image.height) // 2)
    elif position == "bottom":
        barcode_top = max(0, (barcode_area_height - best_image.height) // 2)
    else:
        barcode_top = max(0, (height - best_image.height) // 2)
    result.alpha_composite(best_image, (barcode_left, barcode_top))

    if position != "none" and text_font is not None:
        draw = draw_mod.Draw(result)
        left, top, right, bottom = draw.textbbox((0, 0), content, font=text_font)
        text_width = right - left
        text_height = bottom - top
        text_x = max(0, (width - text_width) // 2)
        if position == "top":
            text_y = max(0, (text_box_height - text_height) // 2 - top)
        else:
            text_y = barcode_area_height + max(0, (text_box_height - text_height) // 2 - top)
        draw.text((text_x, text_y), content, font=text_font, fill="black")
    return result


def _draw_reportlab_node(
    image: Any,
    draw: Any,
    node: Any,
    transform: tuple[float, float, float, float, float, float],
    canvas_height: int,
) -> None:
    node_type = node.__class__.__name__
    node_transform = _compose_transform(transform, _normalize_transform(getattr(node, "transform", None)))

    if node_type in {"Drawing", "Group"}:
        for child in getattr(node, "contents", []) or []:
            _draw_reportlab_node(image, draw, child, node_transform, canvas_height)
        return

    if node_type == "Rect":
        fill = _reportlab_color_to_rgba(getattr(node, "fillColor", None))
        stroke = _reportlab_color_to_rgba(getattr(node, "strokeColor", None))
        if not fill and not stroke:
            return

        corners = [
            _transform_point(node_transform, float(node.x), float(node.y)),
            _transform_point(node_transform, float(node.x + node.width), float(node.y)),
            _transform_point(node_transform, float(node.x), float(node.y + node.height)),
            _transform_point(node_transform, float(node.x + node.width), float(node.y + node.height)),
        ]
        min_x = min(point[0] for point in corners)
        max_x = max(point[0] for point in corners)
        min_y = min(point[1] for point in corners)
        max_y = max(point[1] for point in corners)

        left = max(0, int(math.floor(min_x)))
        right = min(image.width, max(left + 1, int(math.ceil(max_x))))
        top = max(0, int(math.floor(canvas_height - max_y)))
        bottom = min(image.height, max(top + 1, int(math.ceil(canvas_height - min_y))))
        if left >= right or top >= bottom:
            return
        draw.rectangle((left, top, right - 1, bottom - 1), fill=fill, outline=stroke)
        return

    if node_type == "String":
        text = str(getattr(node, "text", "") or "")
        if not text:
            return

        baseline_x, baseline_y = _transform_point(
            node_transform,
            float(getattr(node, "x", 0.0)),
            float(getattr(node, "y", 0.0)),
        )
        a, b, c, d, _, _ = node_transform
        scale_x = math.hypot(a, b) or 1.0
        scale_y = math.hypot(c, d) or 1.0
        font_size = max(1, int(round(float(getattr(node, "fontSize", 12.0)) * max(scale_x, scale_y))))
        font = load_font(font_size, getattr(node, "fontName", None))
        fill = _reportlab_color_to_rgba(getattr(node, "fillColor", None)) or (0, 0, 0, 255)

        try:
            ascent, _ = font.getmetrics()
        except AttributeError:
            ascent = font_size

        left, _, right, _ = draw.textbbox((0, 0), text, font=font)
        text_width = right - left
        anchor = (getattr(node, "textAnchor", "") or "").lower()
        if anchor == "middle":
            text_x = baseline_x - (text_width / 2.0)
        elif anchor in {"end", "right"}:
            text_x = baseline_x - text_width
        else:
            text_x = baseline_x
        text_y = canvas_height - baseline_y - ascent
        draw.text((text_x, text_y), text, font=font, fill=fill)
        return

    if hasattr(node, "draw"):
        _draw_reportlab_node(image, draw, node.draw(), node_transform, canvas_height)


def _render_barcode_drawing(drawing: Any) -> Any:
    image_mod, draw_mod, _, _, _ = image_modules()
    image = image_mod.new(
        "RGBA",
        (max(1, int(round(float(getattr(drawing, "width", 1.0))))), max(1, int(round(float(getattr(drawing, "height", 1.0)))))),
        "white",
    )
    draw = draw_mod.Draw(image)
    _draw_reportlab_node(image, draw, drawing, _identity_transform(), image.height)
    return image


def draw_barcode(
    content: str,
    width: int,
    height: int,
    barcode_type: str = "CODE128",
    human_readable: str = "none",
    font_name: str | None = None,
    font_size: int = 12,
) -> Any:
    image_mod, _, _, _, _ = image_modules()
    barcode_type = (barcode_type or "CODE128").upper()
    treepoem_image = _draw_treepoem_barcode(
        content,
        max(1, width),
        max(1, height),
        barcode_type,
        human_readable,
        font_name,
        font_size,
    )
    if treepoem_image is not None:
        return treepoem_image
    reportlab_barcode = require_module("reportlab.graphics.barcode", "reportlab")
    render_pm = require_module("reportlab.graphics.renderPM", "reportlab")

    type_map = {
        "CODE128": "Code128",
        "CODE39": "Standard39",
        "CODE93": "Extended93",
        "EAN8": "EAN8",
        "EAN13": "EAN13",
        "ITF": "I2of5",
        "UPC": "UPCA",
        "CODABAR": "Codabar",
    }
    human = human_readable in {"top", "bottom", "all", True}
    reportlab_name = type_map.get(barcode_type, "Code128")
    try:
        drawing = reportlab_barcode.createBarcodeDrawing(
            reportlab_name,
            value=content,
            width=max(1, width),
            height=max(1, height),
            barHeight=max(1, height * 0.7),
            humanReadable=human,
        )
        try:
            png_bytes = render_pm.drawToString(drawing, fmt="PNG")
            return image_mod.open(io.BytesIO(png_bytes)).convert("RGBA")
        except Exception:
            return _render_barcode_drawing(drawing)
    except Exception:
        return _barcode_placeholder(content, width, height)


def paste_image(base_image: Any, overlay: Any, left: int, top: int, angle: float | None = None) -> None:
    overlay = overlay.convert("RGBA")
    if angle:
        overlay = rotate_image(overlay, angle)
    base_image.alpha_composite(overlay, (int(round(left)), int(round(top))))


def serialize_payload_value(value: Any) -> Any:
    if isinstance(value, Path):
        return os.fspath(value)
    return value


def convert_pdf_to_images(pdf_file: str | os.PathLike[str], dpi: int = 203) -> list[Any]:
    image_mod, _, _, _, _ = image_modules()
    pdfium = require_module("pypdfium2", "pypdfium2")
    scale = max(1, dpi) / 72.0
    document = pdfium.PdfDocument(os.fspath(pdf_file))
    images: list[Any] = []
    for index in range(len(document)):
        page = document[index]
        rendered = page.render(scale=scale)
        pil_image = rendered.to_pil().convert("RGBA")
        images.append(pil_image)
    return images


def convert_pdf_to_image(pdf_file: str | os.PathLike[str], dpi: int = 203) -> Any:
    return convert_pdf_to_images(pdf_file, dpi=dpi)[0]


def parse_json_if_needed(value: Any) -> Any:
    if isinstance(value, str):
        text = value.strip()
        if text.startswith("{") or text.startswith("["):
            return json.loads(text)
    return value


def compact_dict(items: Iterable[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in items:
        if value is None:
            continue
        result[key] = serialize_payload_value(value)
    return result
