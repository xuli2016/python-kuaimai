from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from kuaimai_core.common import JavaBeanMixin
from kuaimai_core.utils import (
    base64_to_image,
    encode_base64,
    get_esc_image_bytes,
    get_tspl_image_bytes,
    image_to_base64,
    merge_bytes,
    remove_base64_header,
)


@dataclass
class QueryDeviceExistRequest(JavaBeanMixin):
    sn: str | None = None


@dataclass
class QueryDeviceStatusRequest(JavaBeanMixin):
    sn: str | None = None
    sns: Any = None


@dataclass
class EscInstructRequest(JavaBeanMixin):
    sn: str | None = None
    instructions: str | None = None
    copies: int | None = None
    volume: int | None = None
    volumeContent: str | None = None
    volumeIndex: int | None = None


@dataclass
class TsplInstructRequest(JavaBeanMixin):
    sn: str | None = None
    instructs: str | None = None
    extra: str | None = None
    prereq: str | None = None


@dataclass
class ResultRequest(JavaBeanMixin):
    sn: str | None = None
    jobIds: Any = None
    jobIdStr: str | None = None


@dataclass
class CombinationRequest(JavaBeanMixin):
    sn: str | None = None
    instructs: str | None = None
    extra: str | None = None
    prereq: str | None = None


@dataclass
class EscTemplatePrintRequest(JavaBeanMixin):
    sn: str | None = None
    templateId: int | None = None
    renderDataJson: Any = None
    renderData: str | None = None
    cut: bool | None = None
    volume: int | None = None
    volumeIndex: int | None = None
    volumeContent: str | None = None
    copies: int | None = None
    type: int | None = None
    endFeed: int | None = None


@dataclass
class TsplTemplatePrintRequest(JavaBeanMixin):
    sn: str | None = None
    templateId: int | None = None
    renderDataJson: Any = None
    renderDataArray: Any = None
    renderDataJsonArray: Any = None
    printTimes: int | None = None
    image: bool | None = None
    imei: str | None = None
    dpi: int | None = None


@dataclass
class TsplTemplateWriteRequest(JavaBeanMixin):
    sn: str | None = None
    templateId: int | None = None
    renderData: str | None = None
    renderDataJson: Any = None
    renderDataJsonArray: Any = None
    printTimes: int | None = None


@dataclass
class BindDeviceRequest(JavaBeanMixin):
    sn: str | None = None
    deviceKey: str | None = None
    bindName: str | None = None
    noteName: str | None = None


@dataclass
class UnbindDeviceRequest(JavaBeanMixin):
    sn: str | None = None
    deviceKey: str | None = None


@dataclass
class TsplXmlWriteRequest(JavaBeanMixin):
    sn: str | None = None
    xmlStr: str | None = None
    printTimes: int | None = None
    image: bool | None = True
    jobs: Any = None


@dataclass
class EscXmlWriteRequest(JavaBeanMixin):
    sn: str | None = None
    instructions: str | None = None
    volume: int | None = None
    volumeIndex: int | None = None
    cut: bool | None = None


@dataclass
class TsplImageRequest(JavaBeanMixin):
    sn: str | None = None
    imageBase64: str | None = None
    bufferedImage: Any = None
    printTimes: int | None = None
    setWidth: int | None = None
    setHeight: int | None = None
    dpi: int | None = None


@dataclass
class EscImageRequest(JavaBeanMixin):
    sn: str | None = None
    imageBase64: str | None = None
    bufferedImage: Any = None
    endFeed: int | None = None
    printWidth: int | None = None


@dataclass
class TsplPdfPrintRequest(JavaBeanMixin):
    sn: str | None = None
    file: Any = None
    width: int | None = None
    height: int | None = None
    dpi: int | None = None


@dataclass
class EscPdfPrintRequest(JavaBeanMixin):
    sn: str | None = None
    file: Any = None
    printWidth: int | None = None
    endFeed: int | None = None


@dataclass
class AdjustDeviceDensityRequest(JavaBeanMixin):
    sn: str | None = None
    density: int | None = None


@dataclass
class CancelJobRequest(JavaBeanMixin):
    sn: str | None = None


@dataclass
class BroadcastRequest(JavaBeanMixin):
    sn: str | None = None
    volume: int | None = None
    volumeContent: str | None = None


@dataclass
class GetCainiaoCodeRequest(JavaBeanMixin):
    imei: str | None = None


@dataclass
class CainiaoBindRequest(JavaBeanMixin):
    imei: str | None = None
    code: str | None = None


@dataclass
class CainiaoPrintRequest(JavaBeanMixin):
    imageBase64Data: str | None = None
    imei: str | None = None


class TsplInstructCreator(JavaBeanMixin):
    def __init__(self) -> None:
        self.instructs = ""
        self.instructsByte = bytearray(b"CLS\r\n")

    def _append(self, command: str | bytes) -> "TsplInstructCreator":
        if isinstance(command, str):
            self.instructsByte.extend(command.encode("gbk"))
        else:
            self.instructsByte.extend(command)
        return self

    def setSize(self, tsplInstructCreator: "TsplInstructCreator" | None = None, width: int | None = None, height: int | None = None) -> "TsplInstructCreator":
        target = tsplInstructCreator or self
        width = 75 if width is None else width
        height = 100 if height is None else height
        return target._append(f"SIZE {width} mm,{height} mm\r\n")

    def addText(
        self,
        tsplInstructCreator: "TsplInstructCreator" | None,
        content: str,
        x: int | None = None,
        y: int | None = None,
        font: str | None = None,
        bold: int | None = None,
        xMultiple: int | None = None,
        yMultiple: int | None = None,
        rotate: int | None = None,
        waterMark: int | None = None,
        bgbx: int | None = None,
        bgby: int | None = None,
        bgbWidth: int | None = None,
        bgbHeight: int | None = None,
    ) -> "TsplInstructCreator":
        target = tsplInstructCreator or self
        x = 1 if x is None else x
        y = 1 if y is None else y
        font = "1" if font is None else font
        xMultiple = 1 if xMultiple is None else xMultiple
        yMultiple = 1 if yMultiple is None else yMultiple
        rotate = 0 if rotate is None else rotate
        if bold:
            target._append(f"BOLD {bold}\r\n")
        if waterMark is not None:
            target._append(f"WATERMARK {waterMark}kmp\r\n")
        target._append(f'TEXT {x},{y},"{font}",{rotate},{xMultiple},{yMultiple},"{content or ""}"\r\n')
        if None not in (bgbx, bgby, bgbWidth, bgbHeight):
            target._append(f"REVERSE {bgbx},{bgby},{bgbWidth},{bgbHeight}\r\n")
        return target

    def addBarcode(
        self,
        tsplInstructCreator: "TsplInstructCreator" | None,
        content: str,
        x: int | None = None,
        y: int | None = None,
        codeType: str | None = None,
        height: int | None = None,
        narrow: int | None = None,
        wide: int | None = None,
        style: int | None = None,
        rotate: int | None = None,
    ) -> "TsplInstructCreator":
        target = tsplInstructCreator or self
        x = 1 if x is None else x
        y = 1 if y is None else y
        codeType = "128" if codeType is None else codeType
        height = 100 if height is None else height
        narrow = 2 if narrow is None else narrow
        wide = 2 if wide is None else wide
        style = 2 if style is None else style
        rotate = 0 if rotate is None else rotate
        target._append(
            f'BARCODE {x},{y},"{codeType}",{height},{style},{rotate},{narrow},{wide},"{content or ""}"\r\n'
        )
        return target

    def addQrcode(
        self,
        tsplInstructCreator: "TsplInstructCreator" | None,
        content: str,
        x: int | None = None,
        y: int | None = None,
        cellWidth: int | None = None,
        rotate: int | None = None,
        eccLevel: str | None = None,
        mode: str | None = None,
        model: str | None = None,
        mask: str | None = None,
    ) -> "TsplInstructCreator":
        target = tsplInstructCreator or self
        x = 1 if x is None else x
        y = 1 if y is None else y
        cellWidth = 7 if cellWidth is None else cellWidth
        rotate = 0 if rotate is None else rotate
        eccLevel = "L" if eccLevel is None else eccLevel
        mode = "M" if mode is None else mode
        model = "M1" if model is None else model
        mask = "S3" if mask is None else mask
        target._append(f'QRCODE {x},{y},{eccLevel},{cellWidth},{mode},{rotate},{model},{mask},"{content or ""}"\r\n')
        return target

    def addImg(self, tsplInstructCreator: "TsplInstructCreator" | None, base64Content: str, x: int | None = None, y: int | None = None) -> "TsplInstructCreator":
        target = tsplInstructCreator or self
        if not base64Content:
            return target
        image = base64_to_image(remove_base64_header(base64Content) or "")
        x = 1 if x is None else x
        y = 1 if y is None else y
        target._append(get_tspl_image_bytes(image))
        return target

    def addBox(self, tsplInstructCreator: "TsplInstructCreator" | None, x: int | None = None, y: int | None = None, xEnd: int | None = None, yEnd: int | None = None, thickness: int | None = None, radius: int | None = None) -> "TsplInstructCreator":
        target = tsplInstructCreator or self
        x = 1 if x is None else x
        y = 1 if y is None else y
        xEnd = 100 if xEnd is None else xEnd
        yEnd = 100 if yEnd is None else yEnd
        thickness = 1 if thickness is None else thickness
        radius = 0 if radius is None else radius
        if radius:
            target._append(f"BOX {x},{y},{xEnd},{yEnd},{thickness},{radius}\r\n")
        else:
            target._append(f"BOX {x},{y},{xEnd},{yEnd},{thickness}\r\n")
        return target

    def addCircle(self, tsplInstructCreator: "TsplInstructCreator" | None, x: int | None = None, y: int | None = None, thickness: int | None = None, diameter: int | None = None) -> "TsplInstructCreator":
        target = tsplInstructCreator or self
        x = 1 if x is None else x
        y = 1 if y is None else y
        thickness = 1 if thickness is None else thickness
        diameter = 100 if diameter is None else diameter
        return target._append(f"CIRCLE {x},{y},{diameter},{thickness}\r\n")

    def addEllipse(self, tsplInstructCreator: "TsplInstructCreator" | None, x: int | None = None, y: int | None = None, width: int | None = None, height: int | None = None, thickness: int | None = None) -> "TsplInstructCreator":
        target = tsplInstructCreator or self
        x = 1 if x is None else x
        y = 1 if y is None else y
        width = 100 if width is None else width
        height = 50 if height is None else height
        thickness = 1 if thickness is None else thickness
        return target._append(f"ELLIPSE {x},{y},{width},{height},{thickness},\r\n")

    def addBar(self, tsplInstructCreator: "TsplInstructCreator" | None, x: int | None = None, y: int | None = None, width: int | None = None, height: int | None = None) -> "TsplInstructCreator":
        target = tsplInstructCreator or self
        x = 1 if x is None else x
        y = 1 if y is None else y
        width = 100 if width is None else width
        height = 2 if height is None else height
        return target._append(f"BAR {x},{y},{width},{height}\r\n")

    def print(self, tsplInstructRequest: TsplInstructRequest | None = None, tsplInstructCreator: "TsplInstructCreator" | None = None, num: int | None = None) -> str:
        target = tsplInstructCreator or self
        num = 1 if num is None else num
        target._append(f"PRINT 1,{num}\r\n")
        encoded = encode_base64(bytes(target.instructsByte))
        if tsplInstructRequest is not None:
            tsplInstructRequest.setPrereq("FFFF01")
            tsplInstructRequest.setInstructs(encoded)
        return encoded


class EscInstructCreator(JavaBeanMixin):
    def __init__(self) -> None:
        self.instructions = "1b40"
        self.cut: int | None = None

    def _append_hex(self, payload: bytes) -> "EscInstructCreator":
        self.instructions += payload.hex()
        return self

    def setSize(self, escInstructCreator: "EscInstructCreator" | None = None, width: int | None = None) -> "EscInstructCreator":
        target = escInstructCreator or self
        width = 54 if width is None else width
        return target._append_hex(bytes([31, 27, 26, 1, 2, 4, width]))

    def addText(
        self,
        escInstructCreator: "EscInstructCreator" | None,
        content: str,
        font: str | None = None,
        align: str | None = None,
        feed: int | None = None,
        nextX: int | None = None,
        bold: int | None = None,
        unline: int | None = None,
        rota: int | None = None,
    ) -> "EscInstructCreator":
        target = escInstructCreator or self
        align_map = {"left": 0, "center": 1, "right": 2}
        align_value = align_map.get((align or "center").lower(), 1)
        font_value = int(font, 16) if font else 0
        feed = 1 if feed is None else feed
        nextX = 0 if nextX is None else nextX
        bold = 0 if bold is None else bold
        unline = 0 if unline is None else unline
        rota = 0 if rota is None else rota
        x_value = nextX % 255
        y_value = nextX // 255
        target._append_hex(bytes([0x1D, 0x21, font_value]))
        target._append_hex(bytes([0x1B, 0x61, align_value]))
        target._append_hex(bytes([0x1B, 0x45, bold]))
        target._append_hex(bytes([0x1B, 0x2D, unline]))
        target._append_hex(bytes([0x1B, 0x56, rota]))
        target._append_hex((content or "").encode("gbk"))
        if feed == 0:
            target._append_hex(bytes([0x1B, 0x24, x_value, y_value]))
        else:
            target._append_hex(bytes([0x1B, 0x64, feed]))
        return target

    def addBarcode(
        self,
        escInstructCreator: "EscInstructCreator" | None,
        content: str,
        height: int | None = None,
        wide: int | None = None,
        font: int | None = None,
        showT: str | None = None,
        model: int | None = None,
        align: str | None = None,
        feed: int | None = None,
    ) -> "EscInstructCreator":
        target = escInstructCreator or self
        height = 80 if height is None else height
        wide = 2 if wide is None else wide
        font = 0 if font is None else font
        model = 73 if model is None else model
        feed = 1 if feed is None else feed
        align_map = {"left": 0, "center": 1, "right": 2}
        align_value = align_map.get((align or "left").lower(), 0)
        show_map = {"false": 0, "up": 1, "down": 2, "all": 3}
        show_value = show_map.get((showT or "down").lower(), 2)
        target._append_hex(bytes([0x1B, 0x61, align_value]))
        target._append_hex(bytes([0x1D, 0x68, height]))
        target._append_hex(bytes([0x1D, 0x77, wide]))
        target._append_hex(bytes([0x1D, 0x66, font]))
        target._append_hex(bytes([0x1D, 0x48, show_value]))
        payload = (content or "").encode("gbk")
        if model == 73:
            target._append_hex(bytes([0x1D, 0x6B, model, len(payload) + 2, 0x7B, 0x41]) + payload)
        else:
            target._append_hex(bytes([0x1D, 0x6B, model, len(payload)]) + payload)
        target._append_hex(bytes([0x1B, 0x64, feed]))
        return target

    def addQrcode(
        self,
        escInstructCreator: "EscInstructCreator" | None,
        content: str,
        size: int | None = None,
        align: str | None = None,
        feed: int | None = None,
    ) -> "EscInstructCreator":
        target = escInstructCreator or self
        size = 3 if size is None else size
        feed = 1 if feed is None else feed
        align_map = {"left": 0, "center": 1, "right": 2}
        align_value = align_map.get((align or "left").lower(), 0)
        data = (content or "").encode("utf-8")
        length = len(data) + 3
        pl = length % 256
        ph = length // 256
        target._append_hex(bytes([0x1B, 0x61, align_value]))
        target._append_hex(bytes([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x43, size]))
        target._append_hex(bytes([0x1D, 0x28, 0x6B, pl, ph, 0x31, 0x50, 0x30]) + data)
        target._append_hex(bytes([0x1D, 0x28, 0x6B, 0x03, 0x00, 0x31, 0x51, 0x30]))
        target._append_hex(bytes([0x1B, 0x64, feed]))
        return target

    def addImg(
        self,
        escInstructCreator: "EscInstructCreator" | None,
        content: str,
        size: int | None = None,
        align: str | None = None,
        feed: int | None = None,
    ) -> "EscInstructCreator":
        target = escInstructCreator or self
        if not content:
            return target
        align_map = {"left": 0, "center": 1, "right": 2}
        align_value = align_map.get((align or "left").lower(), 0)
        feed = 1 if feed is None else feed
        image = base64_to_image(remove_base64_header(content) or "")
        target._append_hex(bytes([0x1B, 0x61, align_value]))
        target._append_hex(get_esc_image_bytes(image))
        target._append_hex(bytes([0x1B, 0x64, feed]))
        return target

    def print(self, escInstructCreator: "EscInstructCreator" | None = None) -> "EscInstructCreator":
        target = escInstructCreator or self
        if target.cut == 1:
            target._append_hex(bytes([0x1D, 0x56, 0x00]))
        self.instructions = encode_base64(bytes.fromhex(target.instructions))
        return self


__all__ = [
    "AdjustDeviceDensityRequest",
    "BindDeviceRequest",
    "BroadcastRequest",
    "CainiaoBindRequest",
    "CainiaoPrintRequest",
    "CancelJobRequest",
    "CombinationRequest",
    "EscImageRequest",
    "EscInstructCreator",
    "EscInstructRequest",
    "EscPdfPrintRequest",
    "EscTemplatePrintRequest",
    "EscXmlWriteRequest",
    "GetCainiaoCodeRequest",
    "QueryDeviceExistRequest",
    "QueryDeviceStatusRequest",
    "ResultRequest",
    "TsplImageRequest",
    "TsplInstructCreator",
    "TsplInstructRequest",
    "TsplPdfPrintRequest",
    "TsplTemplatePrintRequest",
    "TsplTemplateWriteRequest",
    "TsplXmlWriteRequest",
    "UnbindDeviceRequest",
]

