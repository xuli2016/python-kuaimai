BASE_URL = "http://cloud.kuaimai.com/api/cloud/"
VERSION = "1.0.0"
DEFAULT_TIMEOUT = 20.0

COMMON_FONT_FAMILIES = (
    "PingFang SC",
    "KaiTi",
    "Microsoft YaHei",
    "SimSun",
    "Noto Sans CJK SC",
    "Arial Unicode MS",
    "DejaVu Sans",
)

COMMON_FONT_PATHS = (
    "/System/Library/Fonts/PingFang.ttc",
    "~/Library/Fonts/SIMKAI.TTF",
    "/System/Library/Fonts/Supplemental/Kaiti.ttc",
    "/System/Library/Fonts/Supplemental/STKaiti.ttf",
    "/System/Library/Fonts/Supplemental/Songti.ttc",
    "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
    "/Library/Fonts/Arial Unicode.ttf",
    "C:/Windows/Fonts/simkai.ttf",
    "C:/Windows/Fonts/msyh.ttc",
    "C:/Windows/Fonts/msyhbd.ttc",
    "C:/Windows/Fonts/simsun.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
    "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
)

FONT_ALIAS_FAMILIES = {
    "kaiti": ("KaiTi", "楷体", "SimKai", "KaiTi_GB2312", "STKaiti"),
    "simsun": ("SimSun", "宋体", "STSong"),
    "microsoftyahei": ("Microsoft YaHei", "微软雅黑"),
    "pingfangsc": ("PingFang SC", "PingFangSC"),
}

FONT_HINT_PATHS = {
    "kaiti": (
        "~/Library/Fonts/SIMKAI.TTF",
        "/System/Library/Fonts/Supplemental/Kaiti.ttc",
        "/System/Library/Fonts/Supplemental/STKaiti.ttf",
        "C:/Windows/Fonts/simkai.ttf",
    ),
    "simsun": (
        "/System/Library/Fonts/Supplemental/Songti.ttc",
        "C:/Windows/Fonts/simsun.ttc",
    ),
    "microsoftyahei": (
        "C:/Windows/Fonts/msyh.ttc",
        "C:/Windows/Fonts/msyhbd.ttc",
    ),
    "pingfangsc": (
        "/System/Library/Fonts/PingFang.ttc",
    ),
}
