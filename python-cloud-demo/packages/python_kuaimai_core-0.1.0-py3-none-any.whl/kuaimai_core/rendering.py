from __future__ import annotations

import math
from typing import Any

from kuaimai_core.bean import TsplImageBO
from kuaimai_core.utils import (
    calculate_image_size_in_kb,
    draw_barcode,
    draw_qrcode,
    get_tspl_image_bytes,
    image_modules,
    load_font,
    merge_bytes,
    mm_to_pixels,
    parse_json_if_needed,
    paste_image,
    remove_base64_header,
    resize_image,
    rotate_image,
    to_binary_image,
)


def _get_float(data: dict[str, Any], key: str, default: float) -> float:
    value = data.get(key)
    if value is None:
        return default
    return float(value)


def _get_int(data: dict[str, Any], key: str, default: int) -> int:
    return int(round(_get_float(data, key, default)))


def get_content(data: dict[str, Any], content: Any, replace_data: dict[str, Any]) -> Any:
    bind_table = data.get("bindTable")
    bind_key = data.get("bindTableDataKey")
    if bind_table:
        table = replace_data.get(bind_table) or []
        if table:
            row = table[0] or {}
            return row.get(bind_key, "") or ""
    return content


def _text_width(draw: Any, text: str, font: Any) -> int:
    if not text:
        return 0
    left, _, right, _ = draw.textbbox((0, 0), text, font=font)
    return int(right - left)


def wrap_text(draw: Any, content: str, width: int, font: Any, max_rows: int | None = None) -> list[str]:
    if not content:
        return [""]
    lines: list[str] = []
    current = ""
    for char in content:
        candidate = current + char
        if current and _text_width(draw, candidate, font) > width:
            lines.append(current)
            current = char
            if max_rows and len(lines) >= max_rows:
                break
        else:
            current = candidate
    if current and (not max_rows or len(lines) < max_rows):
        lines.append(current)
    return lines or [content]


def _render_text(base_image: Any, obj: dict[str, Any], replace_data: dict[str, Any], rate: float) -> None:
    image_mod, draw_mod, _, color_mod, _ = image_modules()
    width = int(_get_float(obj, "width", 24) * _get_float(obj, "scaleX", 1.0) * rate)
    font_size = max(10, int(_get_float(obj, "fontSize", 12) * _get_float(obj, "scaleX", 1.0) * rate))
    left = int(_get_float(obj, "left", 0.0) * rate)
    top = int(_get_float(obj, "top", 0.0) * rate)
    font_family = obj.get("fontFamily")
    font = load_font(font_size, font_family)
    text = get_content(obj, obj.get("text", "") or "", replace_data)
    align = (obj.get("textAlign") or "left").lower()
    max_rows = obj.get("kmTextboxMaxRows")
    angle = float(obj.get("angle") or 0)
    underline = bool(obj.get("underline"))
    linethrough = bool(obj.get("linethrough"))
    reverse = (obj.get("backgroundColor") or "").lower() == "#000"

    temp = image_mod.new("RGBA", (max(width, 1), max(font_size * 4, 64)), (255, 255, 255, 0))
    draw = draw_mod.Draw(temp)
    lines = wrap_text(draw, str(text), max(width, 1), font, max_rows=max_rows)
    line_height = font_size + 8
    total_height = max(line_height * len(lines), font_size + 8)
    temp = image_mod.new("RGBA", (max(width, 1), max(total_height, 1)), (255, 255, 255, 0))
    draw = draw_mod.Draw(temp)

    y = 0
    for line in lines:
        line_width = _text_width(draw, line, font)
        x = 0
        if align == "center":
            x = max(0, (width - line_width) // 2)
        elif align == "right":
            x = max(0, width - line_width)
        if reverse:
            bbox = draw.textbbox((x, y), line, font=font)
            draw.rectangle(bbox, fill="black")
            fill = "white"
        else:
            fill = "black"
        draw.text((x, y), line, font=font, fill=fill)
        if underline:
            draw.line((x, y + font_size, x + line_width, y + font_size), fill=fill, width=1)
        if linethrough:
            draw.line((x, y + font_size // 2, x + line_width, y + font_size // 2), fill=fill, width=1)
        y += line_height

    paste_image(base_image, temp, left, top, angle=angle if angle > 5 else None)


def _render_code(base_image: Any, obj: dict[str, Any], replace_data: dict[str, Any], rate: float) -> None:
    left = int(_get_float(obj, "left", 0.0) * rate)
    top = int(_get_float(obj, "top", 0.0) * rate)
    width = int(_get_float(obj, "width", 120.0) * _get_float(obj, "scaleX", 1.0) * rate)
    height = int(_get_float(obj, "height", 80.0) * _get_float(obj, "scaleY", 1.0) * rate)
    content = str(get_content(obj, obj.get("text", "") or "", replace_data) or "")
    if not content:
        return
    angle = float(obj.get("angle") or 0)
    component_type = obj.get("componentType")
    if component_type == "qrcode":
        overlay = draw_qrcode(content, max(1, width), max(1, height))
    else:
        overlay = draw_barcode(
            content,
            max(1, width),
            max(1, height),
            barcode_type=obj.get("barcodeType") or "CODE128",
            human_readable=obj.get("barcodeTextPosition") or "none",
            font_name=obj.get("fontFamily"),
            font_size=max(10, int(_get_float(obj, "fontSize", 12) * rate)),
        )
    paste_image(base_image, overlay, left, top, angle=angle if angle > 5 else None)


def _render_image(base_image: Any, obj: dict[str, Any], replace_data: dict[str, Any], rate: float) -> None:
    left = int(_get_float(obj, "left", 0.0) * rate)
    top = int(_get_float(obj, "top", 0.0) * rate)
    component_type = obj.get("componentType")
    src = obj.get("src", "") if component_type != "imagedata" else ""
    src = get_content(obj, src, replace_data)
    if not src:
        return
    width = int(_get_float(obj, "width", 1.0) * _get_float(obj, "scaleX", 1.0) * rate)
    height = int(_get_float(obj, "height", 1.0) * _get_float(obj, "scaleY", 1.0) * rate)
    overlay = parse_json_if_needed(src)
    if not isinstance(overlay, str):
        return
    from kuaimai_core.utils import base64_to_image

    image = base64_to_image(remove_base64_header(overlay) or "")
    overlay_image = resize_image(image, max(1, width), max(1, height))
    angle = float(obj.get("angle") or 0)
    paste_image(base_image, overlay_image, left, top, angle=angle if angle > 5 else None)


def _render_line(base_image: Any, obj: dict[str, Any], rate: float) -> None:
    _, draw_mod, _, _, _ = image_modules()
    draw = draw_mod.Draw(base_image)
    left = int(_get_float(obj, "left", 0.0) * rate)
    top = int(_get_float(obj, "top", 0.0) * rate)
    width = _get_float(obj, "width", 1.0) * _get_float(obj, "scaleX", 1.0) * rate
    angle = float(obj.get("angle") or 0)
    stroke_width = max(1, int(_get_float(obj, "strokeWidth", 1.0)))
    if angle > 5:
        end_x = left + int(math.cos(math.radians(angle)) * width)
        end_y = top + int(math.sin(math.radians(angle)) * width)
    else:
        end_x = left + int(width)
        end_y = top
    draw.line((left, top, end_x, end_y), fill="black", width=stroke_width)


def _render_rect(base_image: Any, obj: dict[str, Any], rate: float, oval: bool = False) -> None:
    _, draw_mod, _, _, _ = image_modules()
    draw = draw_mod.Draw(base_image)
    left = int(_get_float(obj, "left", 0.0) * rate)
    top = int(_get_float(obj, "top", 0.0) * rate)
    width = int(_get_float(obj, "width", 1.0) * _get_float(obj, "scaleX", 1.0) * rate)
    height = int(_get_float(obj, "height", 1.0) * _get_float(obj, "scaleY", 1.0) * rate)
    stroke_width = max(1, int(_get_float(obj, "strokeWidth", 1.0)))
    fill = "black" if (obj.get("fill") or "").lower() == "black" else None
    outline = "black"
    box = (left, top, left + max(1, width), top + max(1, height))
    if oval:
        if fill:
            draw.ellipse(box, fill=fill, outline=outline, width=stroke_width)
        else:
            draw.ellipse(box, outline=outline, width=stroke_width)
    else:
        if fill:
            draw.rounded_rectangle(box, radius=int(_get_float(obj, "rx", 0.0)), fill=fill, outline=outline, width=stroke_width)
        else:
            draw.rounded_rectangle(box, radius=int(_get_float(obj, "rx", 0.0)), outline=outline, width=stroke_width)


def render_tspl_template(template_payload: dict[str, Any], replace_data: dict[str, Any], print_times: int | None = None) -> TsplImageBO:
    image_mod, _, _, _, _ = image_modules()
    tag_config = parse_json_if_needed(template_payload.get("tagConfig") or {}) or {}
    template_data = parse_json_if_needed(template_payload.get("templateData") or {}) or {}
    width_mm = int(round(float(tag_config.get("width") or 75)))
    height_mm = int(round(float(tag_config.get("height") or 100)))
    print_direction = float(tag_config.get("printDirection") or 0)
    print_times = 1 if print_times is None else print_times
    viewport_transform = template_data.get("viewportTransform") or []
    rate = 1.0
    if viewport_transform:
        canvas_zoom = float(viewport_transform[0] or 1.0)
        canvas_width = float(template_data.get("width") or (width_mm * 8))
        real_canvas_width = canvas_width / canvas_zoom if canvas_zoom else canvas_width
        if real_canvas_width:
            rate = (width_mm * 8) / real_canvas_width

    canvas = image_mod.new("RGBA", (max(8, (width_mm - 1) * 8), max(8, (height_mm - 1) * 8)), "white")
    for obj in template_data.get("objects") or []:
        obj_type = obj.get("type")
        component_type = obj.get("componentType")
        if obj_type == "textbox":
            _render_text(canvas, obj, replace_data, rate)
        elif obj_type == "image" and component_type in {"barcode", "qrcode"}:
            _render_code(canvas, obj, replace_data, rate)
        elif obj_type == "image":
            _render_image(canvas, obj, replace_data, rate)
        elif obj_type == "line":
            _render_line(canvas, obj, rate)
        elif obj_type == "rect":
            _render_rect(canvas, obj, rate, oval=False)
        elif obj_type == "ellipse":
            _render_rect(canvas, obj, rate, oval=True)

    final_image = canvas
    size_width = width_mm
    size_height = height_mm
    if print_direction in {90.0, 270.0}:
        size_width, size_height = height_mm, width_mm
    if print_direction > 5:
        final_image = rotate_image(canvas, print_direction)
    binary_image = to_binary_image(final_image).convert("RGBA")
    instruct = merge_bytes(
        f"SIZE {size_width} mm,{size_height} mm\r\n".encode("gbk"),
        b"CLS\r\n",
        get_tspl_image_bytes(binary_image, compress=True),
        f"PRINT 1,{print_times}\r\n".encode("gbk"),
    )
    return TsplImageBO(bytes=instruct, bufferedImage=binary_image)


__all__ = ["get_content", "render_tspl_template", "wrap_text"]
