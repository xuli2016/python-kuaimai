import math
from typing import Any, Dict, List, Optional

from kuaimai_core.bean import TsplImageBO
from kuaimai_core.utils import (
    calculate_image_size_in_kb,
    draw_barcode,
    draw_qrcode,
    get_tspl_image_bytes,
    image_modules,
    load_font,
    merge_bytes,
    mm_to_pixels,
    parse_json_if_needed,
    paste_image,
    remove_base64_header,
    resize_image,
    rotate_image,
    to_binary_image,
)


def _get_float(data: Dict[str, Any], key: str, default: float) -> float:
    value = data.get(key)
    if value is None:
        return default
    return float(value)


def _get_int(data: Dict[str, Any], key: str, default: int) -> int:
    return int(round(_get_float(data, key, default)))


def get_content(data: Dict[str, Any], content: Any, replace_data: Dict[str, Any]) -> Any:
    bind_table = data.get("bindTable")
    bind_key = data.get("bindTableDataKey")
    if bind_table:
        table = replace_data.get(bind_table) or []
        if table:
            row = table[0] or {}
            return row.get(bind_key, "") or ""
    return content


def _text_width(draw: Any, text: str, font: Any) -> int:
    if not text:
        return 0
    left, _, right, _ = draw.textbbox((0, 0), text, font=font)
    return int(right - left)


def wrap_text(draw: Any, content: str, width: int, font: Any, max_rows: Optional[int] = None) -> List[str]:
    if not content:
        return [""]
    lines: List[str] = []
    current = ""
    for char in content:
        candidate = current + char
        if current and _text_width(draw, candidate, font) > width:
            lines.append(current)
            current = char
            if max_rows and len(lines) >= max_rows:
                break
        else:
            current = candidate
    if current and (not max_rows or len(lines) < max_rows):
        lines.append(current)
    return lines or [content]


def _render_text(
    base_image: Any,
    obj: Dict[str, Any],
    replace_data: Dict[str, Any],
    rate: float,
    dot_scale: float = 1.0,
) -> None:
    image_mod, draw_mod, _, color_mod, _ = image_modules()
    width = int(_get_float(obj, "width", 24) * _get_float(obj, "scaleX", 1.0) * rate)
    font_size = max(
        int(round(10 * dot_scale)),
        int(_get_float(obj, "fontSize", 12) * _get_float(obj, "scaleX", 1.0) * rate),
    )
    left = int(_get_float(obj, "left", 0.0) * rate)
    top = int(_get_float(obj, "top", 0.0) * rate)
    font_family = obj.get("fontFamily")
    font = load_font(font_size, font_family)
    text = get_content(obj, obj.get("text", "") or "", replace_data)
    align = (obj.get("textAlign") or "left").lower()
    max_rows = obj.get("kmTextboxMaxRows")
    angle = float(obj.get("angle") or 0)
    underline = bool(obj.get("underline"))
    linethrough = bool(obj.get("linethrough"))
    reverse = (obj.get("backgroundColor") or "").lower() == "#000"

    temp = image_mod.new(
        "RGBA",
        (max(width, 1), max(font_size * 4, int(round(64 * dot_scale)))),
        (255, 255, 255, 0),
    )
    draw = draw_mod.Draw(temp)
    lines = wrap_text(draw, str(text), max(width, 1), font, max_rows=max_rows)
    line_gap = int(round(8 * dot_scale))
    line_height = font_size + line_gap
    total_height = max(line_height * len(lines), font_size + line_gap)
    temp = image_mod.new("RGBA", (max(width, 1), max(total_height, 1)), (255, 255, 255, 0))
    draw = draw_mod.Draw(temp)

    y = 0
    for line in lines:
        line_width = _text_width(draw, line, font)
        x = 0
        if align == "center":
            x = max(0, (width - line_width) // 2)
        elif align == "right":
            x = max(0, width - line_width)
        if reverse:
            bbox = draw.textbbox((x, y), line, font=font)
            draw.rectangle(bbox, fill="black")
            fill = "white"
        else:
            fill = "black"
        draw.text((x, y), line, font=font, fill=fill)
        if underline:
            draw.line(
                (x, y + font_size, x + line_width, y + font_size),
                fill=fill,
                width=max(1, int(round(dot_scale))),
            )
        if linethrough:
            draw.line(
                (x, y + font_size // 2, x + line_width, y + font_size // 2),
                fill=fill,
                width=max(1, int(round(dot_scale))),
            )
        y += line_height

    paste_image(base_image, temp, left, top, angle=angle if angle > 5 else None)


def _render_code(
    base_image: Any,
    obj: Dict[str, Any],
    replace_data: Dict[str, Any],
    rate: float,
    dot_scale: float = 1.0,
) -> None:
    left = int(_get_float(obj, "left", 0.0) * rate)
    top = int(_get_float(obj, "top", 0.0) * rate)
    width = int(_get_float(obj, "width", 120.0) * _get_float(obj, "scaleX", 1.0) * rate)
    height = int(_get_float(obj, "height", 80.0) * _get_float(obj, "scaleY", 1.0) * rate)
    content = str(get_content(obj, obj.get("text", "") or "", replace_data) or "")
    if not content:
        return
    angle = float(obj.get("angle") or 0)
    component_type = obj.get("componentType")
    if component_type == "qrcode":
        overlay = draw_qrcode(content, max(1, width), max(1, height))
    else:
        overlay = draw_barcode(
            content,
            max(1, width),
            max(1, height),
            barcode_type=obj.get("barcodeType") or "CODE128",
            human_readable=obj.get("barcodeTextPosition") or "none",
            font_name=obj.get("fontFamily"),
            font_size=max(int(round(10 * dot_scale)), int(_get_float(obj, "fontSize", 12) * rate)),
        )
    paste_image(base_image, overlay, left, top, angle=angle if angle > 5 else None)


def _render_image(base_image: Any, obj: Dict[str, Any], replace_data: Dict[str, Any], rate: float) -> None:
    left = int(_get_float(obj, "left", 0.0) * rate)
    top = int(_get_float(obj, "top", 0.0) * rate)
    component_type = obj.get("componentType")
    src = obj.get("src", "") if component_type != "imagedata" else ""
    src = get_content(obj, src, replace_data)
    if not src:
        return
    width = int(_get_float(obj, "width", 1.0) * _get_float(obj, "scaleX", 1.0) * rate)
    height = int(_get_float(obj, "height", 1.0) * _get_float(obj, "scaleY", 1.0) * rate)
    overlay = parse_json_if_needed(src)
    if not isinstance(overlay, str):
        return
    from kuaimai_core.utils import base64_to_image

    image = base64_to_image(remove_base64_header(overlay) or "")
    overlay_image = resize_image(image, max(1, width), max(1, height))
    angle = float(obj.get("angle") or 0)
    paste_image(base_image, overlay_image, left, top, angle=angle if angle > 5 else None)


def _render_line(base_image: Any, obj: Dict[str, Any], rate: float, dot_scale: float = 1.0) -> None:
    _, draw_mod, _, _, _ = image_modules()
    draw = draw_mod.Draw(base_image)
    left = int(_get_float(obj, "left", 0.0) * rate)
    top = int(_get_float(obj, "top", 0.0) * rate)
    width = _get_float(obj, "width", 1.0) * _get_float(obj, "scaleX", 1.0) * rate
    angle = float(obj.get("angle") or 0)
    raw_stroke_width = _get_float(obj, "strokeWidth", 1.0)
    stroke_width = max(
        1,
        int(raw_stroke_width) if dot_scale == 1.0 else int(round(raw_stroke_width * dot_scale)),
    )
    if angle > 5:
        end_x = left + int(math.cos(math.radians(angle)) * width)
        end_y = top + int(math.sin(math.radians(angle)) * width)
    else:
        end_x = left + int(width)
        end_y = top
    if dot_scale > 1.0 and (obj.get("lineType") or "") == "dotted":
        _draw_dotted_line(
            draw,
            left,
            top,
            end_x,
            end_y,
            dash_length=max(1, int(round(16 * dot_scale))),
            gap_length=max(1, int(round(4 * dot_scale))),
            width=stroke_width,
        )
    else:
        draw.line((left, top, end_x, end_y), fill="black", width=stroke_width)


def _draw_dotted_line(
    draw: Any,
    x1: int,
    y1: int,
    x2: int,
    y2: int,
    dash_length: int,
    gap_length: int,
    width: int,
) -> None:
    dx = x2 - x1
    dy = y2 - y1
    length = math.hypot(dx, dy)
    if length <= 0:
        draw.point((x1, y1), fill="black")
        return
    offset = 0.0
    step = dash_length + gap_length
    while offset < length:
        end = min(length, offset + dash_length)
        draw.line(
            (
                int(round(x1 + dx * offset / length)),
                int(round(y1 + dy * offset / length)),
                int(round(x1 + dx * end / length)),
                int(round(y1 + dy * end / length)),
            ),
            fill="black",
            width=width,
        )
        offset += step


def _render_rect(
    base_image: Any,
    obj: Dict[str, Any],
    rate: float,
    oval: bool = False,
    dot_scale: float = 1.0,
) -> None:
    _, draw_mod, _, _, _ = image_modules()
    draw = draw_mod.Draw(base_image)
    left = int(_get_float(obj, "left", 0.0) * rate)
    top = int(_get_float(obj, "top", 0.0) * rate)
    width = int(_get_float(obj, "width", 1.0) * _get_float(obj, "scaleX", 1.0) * rate)
    height = int(_get_float(obj, "height", 1.0) * _get_float(obj, "scaleY", 1.0) * rate)
    raw_stroke_width = _get_float(obj, "strokeWidth", 1.0)
    stroke_width = max(
        1,
        int(raw_stroke_width) if dot_scale == 1.0 else int(round(raw_stroke_width * dot_scale)),
    )
    fill = "black" if (obj.get("fill") or "").lower() == "black" else None
    outline = "black"
    box = (left, top, left + max(1, width), top + max(1, height))
    if oval:
        if fill:
            draw.ellipse(box, fill=fill, outline=outline, width=stroke_width)
        else:
            draw.ellipse(box, outline=outline, width=stroke_width)
    else:
        if fill:
            draw.rounded_rectangle(
                box,
                radius=int(round(_get_float(obj, "rx", 0.0) * dot_scale)),
                fill=fill,
                outline=outline,
                width=stroke_width,
            )
        else:
            draw.rounded_rectangle(
                box,
                radius=int(round(_get_float(obj, "rx", 0.0) * dot_scale)),
                outline=outline,
                width=stroke_width,
            )


def render_tspl_template(
    template_payload: Dict[str, Any],
    replace_data: Dict[str, Any],
    print_times: Optional[int] = None,
) -> TsplImageBO:
    """Render the legacy 203dpi template path without changing its canvas behavior."""
    return _render_tspl_template_at_dpi(
        template_payload,
        replace_data,
        print_times,
        dots_per_mm=8,
        dot_scale=1.0,
        preserve_legacy_canvas_margin=True,
    )


def render_tspl_template_300dpi(
    template_payload: Dict[str, Any],
    replace_data: Dict[str, Any],
    print_times: Optional[int] = None,
) -> TsplImageBO:
    """Render the original 203dpi template model directly onto a 12 dots/mm canvas."""
    return _render_tspl_template_at_dpi(
        template_payload,
        replace_data,
        print_times,
        dots_per_mm=12,
        dot_scale=1.5,
        preserve_legacy_canvas_margin=False,
    )


def _render_tspl_template_at_dpi(
    template_payload: Dict[str, Any],
    replace_data: Dict[str, Any],
    print_times: Optional[int],
    dots_per_mm: int,
    dot_scale: float,
    preserve_legacy_canvas_margin: bool,
) -> TsplImageBO:
    image_mod, _, _, _, _ = image_modules()
    tag_config = parse_json_if_needed(template_payload.get("tagConfig") or {}) or {}
    template_data = parse_json_if_needed(template_payload.get("templateData") or {}) or {}
    width_mm = int(round(float(tag_config.get("width") or 75)))
    height_mm = int(round(float(tag_config.get("height") or 100)))
    print_direction = float(tag_config.get("printDirection") or 0)
    print_times = 1 if print_times is None else print_times
    viewport_transform = template_data.get("viewportTransform") or []
    rate = 1.0
    if viewport_transform:
        canvas_zoom = float(viewport_transform[0] or 1.0)
        canvas_width = float(template_data.get("width") or (width_mm * 8))
        real_canvas_width = canvas_width / canvas_zoom if canvas_zoom else canvas_width
        if real_canvas_width:
            rate = (width_mm * dots_per_mm) / real_canvas_width

    if preserve_legacy_canvas_margin:
        canvas_size = (max(8, (width_mm - 1) * 8), max(8, (height_mm - 1) * 8))
    else:
        canvas_size = (max(1, width_mm * dots_per_mm), max(1, height_mm * dots_per_mm))
    canvas = image_mod.new("RGBA", canvas_size, "white")
    for obj in template_data.get("objects") or []:
        obj_type = obj.get("type")
        component_type = obj.get("componentType")
        if obj_type == "textbox":
            _render_text(canvas, obj, replace_data, rate, dot_scale)
        elif obj_type == "image" and component_type in {"barcode", "qrcode"}:
            _render_code(canvas, obj, replace_data, rate, dot_scale)
        elif obj_type == "image":
            _render_image(canvas, obj, replace_data, rate)
        elif obj_type == "line":
            _render_line(canvas, obj, rate, dot_scale)
        elif obj_type == "rect":
            _render_rect(canvas, obj, rate, oval=False, dot_scale=dot_scale)
        elif obj_type == "ellipse":
            _render_rect(canvas, obj, rate, oval=True, dot_scale=dot_scale)

    final_image = canvas
    size_width = width_mm
    size_height = height_mm
    if print_direction in {90.0, 270.0}:
        size_width, size_height = height_mm, width_mm
    if print_direction > 5:
        final_image = rotate_image(canvas, print_direction)
    binary_image = to_binary_image(final_image).convert("RGBA")
    instruct = merge_bytes(
        f"SIZE {size_width} mm,{size_height} mm\r\n".encode("gbk"),
        b"CLS\r\n",
        get_tspl_image_bytes(binary_image, compress=True),
        f"PRINT 1,{print_times}\r\n".encode("gbk"),
    )
    return TsplImageBO(bytes=instruct, bufferedImage=binary_image)


__all__ = ["get_content", "render_tspl_template", "render_tspl_template_300dpi", "wrap_text"]
